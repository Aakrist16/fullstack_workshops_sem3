<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php include "header.php"; ?>

<ul>
    <li><a href="add_student.php">Add Student Info</a></li>
    <li><a href="upload.php">Upload Portfolio File</a></li>
    <li><a href="students.php">View Students</a></li>
</ul>

<?php include "footer.php"; ?>
</body>
</html>